`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Module Name: sync_fifo_peek
// Description: FIFO sincrona (mesmo clock em escrita e leitura), profundidade
//              e largura parametrizaveis, com leitura COMBINACIONAL do topo
//              (peek), ou seja, rd_data sempre reflete mem[rd_ptr]
//              independente de rd_en. O "pop" (avanco do ponteiro de leitura
//              e decremento de count) so ocorre quando rd_en=1 e a fifo nao
//              esta vazia. Esse comportamento foi escolhido de proposito
//              para ser um substituto "drop-in" da leitura antiga por
//              endereco (mem[addr]), que tambem era combinacional.
//
// Usada para substituir os antigos buffers 'mem' e 'mem_tmp' do
// control_axi_stream_gbe por FIFOs reais ligadas diretamente aos lados
// AXI-Stream (m_axis / s_axis).
//////////////////////////////////////////////////////////////////////////////////
module sync_fifo_peek #(
    parameter WIDTH   = 8,
    parameter DEPTH   = 256,
    parameter ADDR_W  = 8          // log2(DEPTH)
)(
    input  wire                  clk,
    input  wire                  a_sync_nrst,

    input  wire                  wr_en,
    input  wire [WIDTH-1:0]      wr_data,
    output wire                  full,

    input  wire                  rd_en,
    output wire [WIDTH-1:0]      rd_data,   // peek combinacional do topo
    output wire                  empty,

    output wire [ADDR_W:0]       count      // 0..DEPTH (precisa de ADDR_W+1 bits)
);

    reg [WIDTH-1:0]   mem [0:DEPTH-1];
    reg [ADDR_W-1:0]  wr_ptr;
    reg [ADDR_W-1:0]  rd_ptr;
    reg [ADDR_W:0]    count_r;

    assign full    = (count_r == DEPTH[ADDR_W:0]);
    assign empty   = (count_r == {(ADDR_W+1){1'b0}});
    assign count   = count_r;
    assign rd_data = mem[rd_ptr]; // leitura combinacional (nao destrutiva)

    wire do_write = wr_en && !full;
    wire do_read  = rd_en && !empty;

    always @(posedge clk or negedge a_sync_nrst) begin
        if (!a_sync_nrst) begin
            wr_ptr  <= {ADDR_W{1'b0}};
            rd_ptr  <= {ADDR_W{1'b0}};
            count_r <= {(ADDR_W+1){1'b0}};
        end else begin
            if (do_write) begin
                mem[wr_ptr] <= wr_data;
                wr_ptr      <= wr_ptr + 1'b1;
            end
            if (do_read) begin
                rd_ptr <= rd_ptr + 1'b1;
            end
            case ({do_write, do_read})
                2'b10:   count_r <= count_r + 1'b1;
                2'b01:   count_r <= count_r - 1'b1;
                default: count_r <= count_r; // 00 ou 11 -> ocupacao nao muda
            endcase
        end
    end

endmodule