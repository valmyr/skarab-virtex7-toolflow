`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: VIRTUS/UFCG
// Engineer: Valmir F. Silva
//
// Create Date: 06/19/2026 11:40:32 PM
// Design Name:
// Module Name: control_axi_stream_gbe
// Project Name:
// Target Devices:
// Tool Versions:
// Description:
//
// Dependencies:
//
// Revision:
// Revision 0.01 - File Created
// Revision 0.02 - Correcao: captura do primeiro byte de dado perdido na
//                 transicao IDLE->RX_DATA (causa raiz do vazamento do byte
//                 0x6E/110 de frame_rx para dentro de mem[], observado nos
//                 indices 246/247). Ver comentario na condicao de escrita.
// Revision 0.03 - Refatoracao: os buffers 'mem' (dados recebidos via GbE) e
//                 'mem_tmp' (dados recebidos via S_AXIS) deixam de ser
//                 arrays endereçaveis e passam a ser FIFOs de verdade
//                 (sync_fifo_peek), cada uma ligada diretamente a UM lado
//                 AXI-Stream:
//                   - fifo_rx2axi : GbE RX (rx_data)      -> M_AXIS (saida)
//                   - fifo_axi2tx : S_AXIS (entrada)      -> GbE TX (tx_data)
//                 A leitura endereçavel usada para depuracao
//                 (debug_addr_data_gbe / debug_addr_data_fifo e o mux
//                 debug_read_gbe_or_fifo sobre tx_data) e preservada, mas
//                 passa a ler COPIAS-SOMBRA (shadow_mem_gbe / shadow_mem_fifo)
//                 que sao escritas em paralelo as FIFOs e nunca sao
//                 consumidas (pop) - ou seja, o debug fica desacoplado do
//                 datapath real e nao concorre pelo mesmo dado que a FIFO
//                 entrega ao axi_*.
//
//                 ATENCAO - mudanca de comportamento que precisa ser
//                 validada em simulacao/hardware:
//                 1) M_AXIS antes so comecava a transmitir quando
//                    addr_data_local == tx_pkt_len, ou seja, DEPOIS que o
//                    ponteiro de replay local do lado GbE TX tivesse
//                    percorrido o frame inteiro (mem era lido duas vezes:
//                    uma vez pelo eco em tx_data, outra vez do zero por
//                    m_axis). Como fifo_rx2axi agora e uma FIFO de unico
//                    consumidor (so m_axis a esvazia), essa dependencia foi
//                    substituida por "fifo_rx2axi acumulou um frame
//                    completo" (count_rx2axi >= tx_pkt_len). Isso desacopla
//                    o inicio do M_AXIS do andamento do eco em tx_data.
//                 2) Overflow agora e tratado explicitamente: escritas nas
//                    FIFOs sao bloqueadas quando full (antes, no array puro,
//                    o comportamento em overflow nao era garantido/definido
//                    da mesma forma). s_axis_tready tambem passa a respeitar
//                    o full da fifo_axi2tx.
//                 3) Em modo de depuracao (debug_read_gbe_or_fifo=1), o lado
//                    GbE TX passa a ecoar a partir do shadow_mem_gbe (copia
//                    congelada), e NAO mais consome (pop) a fifo_axi2tx nem
//                    a fifo_rx2axi - portanto, se o modo debug ficar ligado
//                    por muito tempo com S_AXIS continuando a empurrar dado,
//                    fifo_axi2tx pode encher (comportamento esperado: quem
//                    "consome de verdade" a fifo_axi2tx e so o eco normal
//                    quando debug=0).
// Additional Comments: Square Kilometer Array Reconfigurable Application Board - SKARAB
//////////////////////////////////////////////////////////////////////////////////


module control_axi_stream_gbe(
    input  wire        clk,
    input  wire        a_sync_nrst,
    input  wire        ce, //Sem uso
    input  wire        rx_valid,
    input  wire [7:0]  rx_data,
    input  wire [9:0]  tx_pkt_len,
    output reg  [7:0]  tx_data,
    output wire        tx_val,
    output wire        tx_eof,
    ///Axi  Sinais
    //Interface Slave AXI Stream (Entrada)
    input wire        s_axis_tvalid,
    input wire [7:0]  s_axis_tdata,
    input wire        s_axis_tlast,
    output reg        s_axis_tready,
    //Interface Master AXI Stream (Saida)
    output reg        m_axis_tvalid,
    output reg [7:0]  m_axis_tdata,
    output reg        m_axis_tlast,
    input  wire       m_axis_tready,
    //Debug Sinais
    input  wire [7:0] debug_addr_data_gbe,
    input  wire [7:0] debug_addr_data_fifo,
    output reg [7:0]  debug_rx_data_mem_gbe,
    output reg [7:0]  debug_rx_data_mem_fifo,
    input  wire       debug_read_gbe_or_fifo,
    input wire [9:0]       decim_factor

);



localparam CMD_SIZE = 4'h08;
localparam IDLE = 2'b00;
localparam RX_DATA = 2'b01;
localparam TX_DATA = 2'b10;
reg [2:0]next_state_tx;
reg [2:0]next_state_rx;
reg [2:0]current_state_tx;
reg [2:0]current_state_rx;
reg [10:0] addr_data_local;
reg [10:0] addr_data_local_next;
wire [10:0] addr_data_local_mux;

// ---------------------------------------------------------------------
// Copias-sombra (somente para os sinais de depuracao). Espelham
// exatamente o que era escrito nos antigos 'mem' e 'mem_tmp', mas nunca
// sao lidas/consumidas pelo datapath real - servem so para
// debug_rx_data_mem_gbe/fifo.
// ---------------------------------------------------------------------
reg [7:0] shadow_mem_gbe[256-1:0];   // espelho do que entra na fifo_rx2axi (RX GbE)
reg [7:0] shadow_mem_fifo[256-1:0];  // espelho do que entra na fifo_axi2tx (S_AXIS)

reg  [7:0] rx_data_ff0, rx_data_ff1;
wire start_frame_reception;
wire start_frame_transmission;

reg sync_reg_start_frame_reception;
reg sync_reg_start_frame_transmission;
wire [10:0] addr_data_write_mux,addr_data_local_mux_r;
reg reg_sync_rx_valid;

reg [7:0]debug_local_data;
reg [31:0]counter_dec;
wire ena_dec;

reg  [7:0] counter_tx;
reg  [7:0] next_state_counter_tx;

reg tx_ena_out;
reg sync_data_valid_tx;

// ---------------------------------------------------------------------
// FIFO_A: fifo_axi2tx -> alimenta o eco normal do lado GbE TX (tx_data)
//         com o que chega pelo S_AXIS (substitui 'mem_tmp')
// FIFO_B: fifo_rx2axi -> alimenta o M_AXIS (saida) com o que chega pelo
//         GbE RX (rx_data) (substitui 'mem')
// ---------------------------------------------------------------------
wire        wr_en_a, full_a, rd_en_a, empty_a;
wire [7:0]  rd_data_a;
wire [8:0]  count_a;

wire        wr_en_b, full_b, rd_en_b, empty_b;
wire [7:0]  rd_data_b;
wire [8:0]  count_b;

sync_fifo_peek #(.WIDTH(8), .DEPTH(256), .ADDR_W(8)) fifo_axi2tx (
    .clk         (clk),
    .a_sync_nrst (a_sync_nrst),
    .wr_en       (wr_en_a),
    .wr_data     (s_axis_tdata),
    .full        (full_a),
    .rd_en       (rd_en_a),
    .rd_data     (rd_data_a),
    .empty       (empty_a),
    .count       (count_a)
);

sync_fifo_peek #(.WIDTH(8), .DEPTH(256), .ADDR_W(8)) fifo_rx2axi (
    .clk         (clk),
    .a_sync_nrst (a_sync_nrst),
    .wr_en       (wr_en_b),
    .wr_data     (rx_data),
    .full        (full_b),
    .rd_en       (rd_en_b),
    .rd_data     (rd_data_b),
    .empty       (empty_b),
    .count       (count_b)
);

// Escrita na fifo_rx2axi: mesma condicao que antes gravava em mem[counter_tx]
// (inclui a correcao do primeiro byte na transicao IDLE->RX_DATA).
assign wr_en_b = rx_valid &&
                 ((current_state_rx == RX_DATA) || start_frame_reception) &&
                 (counter_tx < 248) &&
                 !full_b;

// Escrita na fifo_axi2tx: handshake AXI direto (sem atraso de registrador -
// ver nota de revisao 0.03 sobre o bug do handshake registrado no M_AXIS,
// que se aplica de forma simetrica aqui).
assign wr_en_a = s_axis_tvalid && s_axis_tready && !full_a;

// Pop da fifo_axi2tx: so consome um byte novo quando o lado GbE TX de fato
// avanca o ponteiro de leitura por causa do pacing (ena_dec) E nao estamos
// em modo debug (nesse modo quem alimenta tx_data e o shadow_mem_gbe, e a
// fifo_axi2tx fica intacta).
assign rd_en_a = ena_dec && (current_state_tx == TX_DATA) && !debug_read_gbe_or_fifo;

// Pop da fifo_rx2axi: definido mais abaixo, junto da FSM do M_AXIS
// (ponte FIFO->AXI-Stream: pop exatamente quando o handshake e aceito).

always@(posedge clk, negedge a_sync_nrst)begin
    if(!a_sync_nrst)begin
        //addr_data_local <=8'h00;
        reg_sync_rx_valid    <= 0;
        sync_reg_start_frame_reception<=0;
        sync_reg_start_frame_transmission <=0;
        tx_data <= 8'hca;
        counter_tx <= 0;
        rx_data_ff1 <=0;
        addr_data_local <=0;

    end else begin
        //Logica de escrita no buffer (fifo_rx2axi) + copia-sombra de debug
        //rx_data_ff1 <= rx_valid ? rx_data :rx_data_ff1;
        if(rx_valid)begin
            counter_tx       <=  next_state_counter_tx;
            // CORRECAO: inclui start_frame_reception na condicao.
            // No ciclo em que o cmd_sync_detector pulsa start_frame_reception,
            // current_state_rx ainda e IDLE (a transicao de estado so se
            // efetiva no ciclo seguinte), mas rx_data ja e o PRIMEIRO byte
            // de dado real (data1[0]). Sem esta condicao extra, esse byte
            // era descartado, deslocando toda a captura em 1 posicao.
            if(((current_state_rx == RX_DATA) || start_frame_reception)  && counter_tx < 248) begin
                //248 e o tamanho do pacote menos os codigos de commandos, no caso: 256 - 2*(4) = 248
                shadow_mem_gbe[counter_tx] <= rx_data; // so debug; a gravacao real esta em fifo_rx2axi (wr_en_b)
            end
        end
        else begin
            counter_tx <= counter_tx;
        end
        //Logica de leitura no buffer (fifo_axi2tx normal, ou shadow_mem_gbe em modo debug)

        if(ena_dec && current_state_tx == TX_DATA )begin
            tx_data <= debug_read_gbe_or_fifo ? shadow_mem_gbe[addr_data_local] : rd_data_a;
            addr_data_local <= addr_data_local_next;
        end else begin


            if(addr_data_local < tx_pkt_len)begin
                tx_data <= debug_read_gbe_or_fifo ? shadow_mem_gbe[addr_data_local] : rd_data_a;
            end else begin
                tx_data <= 0;
            end
            addr_data_local <= addr_data_local < tx_pkt_len ? addr_data_local_next:0;

        end

        reg_sync_rx_valid    <= rx_valid;

        sync_reg_start_frame_reception   <= start_frame_reception   ;
        sync_reg_start_frame_transmission<=  start_frame_transmission;
        //tx_ena_out <=current_state_tx == TX_DATA;


    end
end

reg  tx_ena_out_w;
reg sync_data_valid_tx0;
reg sync_dec;
reg [7:0] addr_data_t;
    always@(posedge clk, negedge a_sync_nrst)begin
        if(!a_sync_nrst)begin
            current_state_tx <= IDLE;
            current_state_rx <= IDLE;
            addr_data_t <=0;
            sync_data_valid_tx <=0;
            sync_data_valid_tx0 <=0;
            tx_ena_out =0;
            sync_dec <=0;
            debug_local_data<=0;

        end else begin
            current_state_tx <= next_state_tx;
            current_state_rx <= next_state_rx;


            sync_data_valid_tx0 <= ena_dec ;
            sync_data_valid_tx <= (!ena_dec && sync_data_valid_tx0);
            tx_ena_out  <= tx_ena_out_w ;
            sync_dec <=!tx_ena_out && tx_ena_out_w;
        end
    end

    //Logica de proximo estado da FSM de controle RX
    always@(*)begin
        case(current_state_rx)
            IDLE:begin
                case(start_frame_reception)
                    1'b1:next_state_rx = RX_DATA;
                    1'b0:next_state_rx = IDLE;
                    default:next_state_rx = IDLE;
                endcase

                // CORRECAO: se start_frame_reception pulsou neste ciclo,
                // o byte presente (data1[0]) ja foi capturado (fifo_rx2axi /
                // shadow_mem_gbe[0]) pela condicao adicionada no bloco de
                // escrita. O proximo endereco de debug precisa ser 1, nao 0.
                next_state_counter_tx = start_frame_reception ? 1 : 0;
            end
            RX_DATA:begin
                next_state_counter_tx = counter_tx +1;
                case(counter_tx < tx_pkt_len-1 )
                    1'b1:next_state_rx = RX_DATA;
                    1'b0:next_state_rx = IDLE;
                    default:next_state_rx = IDLE;
                endcase
            end
            default:begin
                next_state_counter_tx = 0;
                next_state_rx = IDLE;
            end
        endcase
    end

    //Logica de proximo estado da FSM de controle TX
    always@(*)begin
        case(current_state_tx)
            IDLE:begin
                case(start_frame_transmission)//Atualizacao do estado de transmissao com base na recepcao
                    1'b1:next_state_tx = TX_DATA;
                    1'b0:next_state_tx = IDLE;
                    default:next_state_tx = IDLE;
                endcase
                tx_ena_out_w = 0;
                addr_data_local_next = 0;
            end
            TX_DATA:begin
                case(addr_data_local < tx_pkt_len)

                    1'b1:begin
                        tx_ena_out_w = 1;
                        next_state_tx = TX_DATA;
                        //addr_data_local_next = addr_data_local < tx_pkt_len ? addr_data_local + 1 : 0;

                        if(addr_data_local < tx_pkt_len && ena_dec)begin
                            addr_data_local_next =  addr_data_local + 1;
                        end else begin
                            addr_data_local_next =  addr_data_local;

                        end
                    end
                    1'b0:begin next_state_tx = start_frame_transmission ?  TX_DATA : IDLE;
                        addr_data_local_next = 0;
                        tx_ena_out_w = 0;
                    end
                    default:begin next_state_tx = IDLE;
                                addr_data_local_next = 0;
                                tx_ena_out_w = 1;
                    end
                endcase
            end
            default:begin
                tx_ena_out_w = 0;
                addr_data_local_next = 0;
                next_state_tx = IDLE;
            end
        endcase
    end





    assign ena_dec       =  counter_dec == decim_factor-1; //Por padrao 15; 15-1 =14
    always @(posedge clk or negedge a_sync_nrst) begin
        if(!a_sync_nrst)begin
            counter_dec <= 0;
        end else begin
            if(tx_ena_out && counter_dec < decim_factor) counter_dec <= counter_dec +1;
            else                               counter_dec <= 0;
        end
    end

assign tx_eof = (addr_data_local == tx_pkt_len - 1) ;
assign tx_val = (tx_ena_out && ena_dec);


//Recepcao SKARAB
cmd_sync_detector cmd_start_frame_reception(
        .clk(clk),
        .ce(ce),
        .a_sync_nrst(a_sync_nrst),
        .rx_data(rx_data),
        .rx_valid(rx_valid),
        .frame_cmd(32'h72_65_63_65), //Frame a ser detectado
        .event_cmd_out(start_frame_reception)
);
//Transmissao SKARAB
cmd_sync_detector cmd_frame_transmission(
        .clk(clk),
        .ce(ce),
        .a_sync_nrst(a_sync_nrst),
        .rx_data(rx_data),     //FIFO Sinais Temporario
        .rx_valid(rx_valid),//FIFO Sinais Temporario
        .frame_cmd(32'h74_72_61_6E),//Frame a ser detectado
        .event_cmd_out(start_frame_transmission)
);


//    always@(*) m_axis_tvalid = s_axis_tvalid;
//    always@(*) m_axis_tdata =s_axis_tdata;
//    always@(*) m_axis_tlast = s_axis_tlast;
//    always@(*) s_axis_tready = m_axis_tready;


//=====================================AXI Master Stream Interface=========================================
/*
//Interface Master AXI Stream (Saida)
    output wire       m_axis_tvalid,
    output reg [7:0] m_axis_tdata,
    output wire       m_axis_tlast,
    input  wire      m_axis_tready,

*/



localparam M_IDLE   = 2'b00;
localparam M_SEND = 2'b01;


(* keep = "true" *)reg [1:0] m_axis_state;
reg [1:0] m_axis_next_state;
reg [9:0] m_byte_cnt; // conta bytes ja entregues no frame atual (0..tx_pkt_len-1)

// ---------------------------------------------------------------------
// NOTA DE PROJETO (rev 0.03): o esquema original usava um handshake
// REGISTRADO (handshake_sm_axis, com 1 ciclo de atraso) tanto para avancar
// o endereco quanto, combinado ao registrador extra de m_axis_tdata,
// resultava em 2 ciclos de atraso entre "tvalid comeca" e "dado real
// disponivel". Isso nunca se manifestava porque m_axis so era habilitado
// depois que o eco local em tx_data (lado GbE TX) ja tinha percorrido o
// frame inteiro - ou seja, na pratica m_axis quase nunca corria de forma
// independente. Ao tornar fifo_rx2axi a fonte direta e unica do M_AXIS
// (pedido do usuario), essa dependencia caiu e o atraso duplo passou a
// causar bytes duplicados no inicio do frame e bytes perdidos no fim
// (confirmado em simulacao). A correcao adotada e a ponte FIFO->AXI-Stream
// classica: tvalid combinacional a partir de !empty, tdata = peek direto
// da fifo (sem registrador extra), e pop (rd_en_b) exatamente no ciclo em
// que o handshake e aceito (tvalid && tready), sem atraso de registrador.
// ---------------------------------------------------------------------

always@(posedge clk, negedge a_sync_nrst)begin
    if(!a_sync_nrst)begin
        m_axis_state <= M_IDLE;
        m_byte_cnt   <= 0;
    end else begin
        m_axis_state <= m_axis_next_state;
        if(m_axis_state == M_IDLE && m_axis_next_state == M_SEND)
            m_byte_cnt <= 0;
        else if(m_axis_state == M_SEND && m_axis_tvalid && m_axis_tready)
            m_byte_cnt <= m_byte_cnt + 1'b1;
    end
end

always@(*) begin
    case(m_axis_state)
        M_IDLE:begin
            // So comeca a transmitir quando a fifo_rx2axi ja acumulou um
            // frame completo vindo do lado GbE RX (ver nota de revisao 0.03).
            m_axis_next_state = ({1'b0,count_b} >= tx_pkt_len) ? M_SEND : M_IDLE;
        end
        M_SEND:begin
            m_axis_next_state = (m_axis_tvalid && m_axis_tready && (m_byte_cnt == tx_pkt_len-1))
                                 ? M_IDLE : M_SEND;
        end
        default: m_axis_next_state = M_IDLE;
    endcase
end

// tvalid/tdata/tlast combinacionais, direto da fifo_rx2axi (sem registrador
// extra) - padrao classico de ponte FIFO -> AXI-Stream.
always@(*) begin
    m_axis_tvalid = (m_axis_state == M_SEND) && !empty_b;
    m_axis_tdata  = rd_data_b;
    m_axis_tlast  = (m_axis_state == M_SEND) && (m_byte_cnt == tx_pkt_len-1);
end

// Pop da fifo_rx2axi acontece exatamente quando o handshake AXI e aceito,
// sem nenhum atraso de registrador.
assign rd_en_b = m_axis_tvalid && m_axis_tready;



//=====================================AXI Slave Stream Interface=========================================
/*

    //Interface Slave AXI Stream (Entrada)
    input wire        s_axis_tvalid,
    input wire [7:0]  s_axis_tdata,
    input wire        s_axis_tlast,
    output reg        s_axis_tready,


*/

localparam S_IDLE   = 1'b1;
localparam S_REC = 1'b0;


reg  s_axis_state;
reg  s_axis_next_state;
reg [9:0] s_byte_cnt; // conta bytes ja recebidos no frame atual (0..tx_pkt_len-1)

// ---------------------------------------------------------------------
// NOTA DE PROJETO (rev 0.03): mesmo ajuste feito no M_AXIS. O esquema
// antigo usava handshake_ms_axis REGISTRADO (1 ciclo de atraso) tanto para
// avancar s_addr_data quanto para decidir quando gravar em mem_tmp /
// shadow_mem_fifo. Isso so era seguro se s_axis_tdata permanecesse valido
// um ciclo extra apos o proprio handshake, o que o protocolo AXI-Stream
// nao garante. Trocado por handshake direto (combinacional), sem atraso -
// mesma logica que corrige o M_AXIS.
// ---------------------------------------------------------------------
wire s_hs = s_axis_tvalid && s_axis_tready; // handshake direto, sem atraso

always@(posedge clk, negedge a_sync_nrst)begin
    if(!a_sync_nrst)begin
        s_axis_state <= S_IDLE;
        s_byte_cnt   <= 0;
    end else begin
        s_axis_state <= s_axis_next_state;
        if(s_hs)begin
            // Grava so a copia-sombra de debug aqui; a gravacao real na
            // fifo_axi2tx e feita por wr_en_a (mesmo handshake s_hs,
            // dentro do proprio modulo fifo).
            shadow_mem_fifo[s_byte_cnt] <= s_axis_tdata;
            s_byte_cnt <= (s_byte_cnt == tx_pkt_len-1) ? 10'd0 : s_byte_cnt + 1'b1;
        end else if(s_axis_state == S_IDLE) begin
            s_byte_cnt <= 0;
        end
    end
end

always@(*) begin
    case(s_axis_state)
        S_IDLE:begin
            s_axis_next_state = s_hs ? S_REC : S_IDLE;
            s_axis_tready = !full_a;
        end
        S_REC:begin
            if(s_hs && (s_byte_cnt == tx_pkt_len-1))begin
                s_axis_next_state = S_IDLE;
                s_axis_tready = !full_a;
            end else begin
                s_axis_next_state = S_REC;
                s_axis_tready = !full_a;
            end
        end
        default:begin
            s_axis_next_state = S_IDLE;
            s_axis_tready = !full_a;
        end
    endcase
end
// Debug: le as copias-sombra (nunca a fifo real), enderecavel livremente.
always@(*) debug_rx_data_mem_gbe  = shadow_mem_gbe[debug_addr_data_gbe];
always@(*) debug_rx_data_mem_fifo = shadow_mem_fifo[debug_addr_data_fifo];


endmodule